from .model_prediction import Model_prediction
from .HLA_inference import HLA_inference
